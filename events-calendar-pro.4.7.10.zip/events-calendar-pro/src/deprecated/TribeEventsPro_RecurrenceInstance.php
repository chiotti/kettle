<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Recurrence__Instance' );


	class TribeEventsPro_RecurrenceInstance extends Tribe__Events__Pro__Recurrence__Instance {

	}