=== Stripe Payments Recaptcha Addon ===
Contributors: alexanderfoxc
Donate link: https://stripe-plugins.com
Tags: stripe
Requires at least: 4.7
Tested up to: 5.1.1
Stable tag: 1.2.0

reCaptcha Addon for Stripe Payments plugin.

== Description ==

reCaptcha Addon for Stripe Payments plugin.

== Changelog ==

= 1.2.0 =
* reCaptcha no longer prevents some buttons from being clicked on (for example, AliPay button).

= 1.1 =
* Some minor improvements.

= 1.0 =
* First test release.